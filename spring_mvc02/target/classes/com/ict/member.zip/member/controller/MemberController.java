package com.ict.member.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ict.member.service.MemberService;
import com.ict.member.vo.MemberVO;

@Controller
public class MemberController {
	
	@Autowired 
	private MemberService memberService;
	
	@PostMapping("/member_login")
	public ModelAndView Login(MemberVO mvo) {
		ModelAndView mv = new ModelAndView("");
		try {
			//회원 아이디 체크
			String m_id = mvo.getM_id();
			MemberVO mbvo = memberService.getMemberLogin(null);
			
			
			
			return mv;
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
		return null;
	}
}
