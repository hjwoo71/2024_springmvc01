package com.ict.edu06.controller;

public class LoginController {

}
